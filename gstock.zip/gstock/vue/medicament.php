<?php
include('header.php');

?><div class="home-content">
<div class="overview-boxes">
    <div class="box">
        <form action="../model/ajoutproduits.php" method="post">
            <h1>Formulaire des produits</h1>
            
            <!-- Nom du produit -->
            
                <label for="nom">Nom du produit</label>
                <input type="text" name="nom" placeholder="Nom du produit" required>
            

            <!-- Description -->
            
                <label for="description">Description</label>
                <input type="text" name="description" placeholder="Description..." required>
            

            <!-- Quantités -->
            
                <label for="quantites">Quantités</label>
                <input type="number" name="quantites" placeholder="Quantités..." required>
            
            
            <!-- Date d'expiration -->
            
                <label for="date_expiration">Date d'expiration</label>
                <input type="date" name="Date_expiration" required>
            

            <!-- Fournisseur -->
        
                <label for="id_fournisseur">Fournisseur</label>
                <select name="id_fournisseur" id="id_fournisseur" required>
                    <option value="">Sélectionner un fournisseur</option>
                    <option value="1">PharmaDistrib</option>
                    <option value="2">MediSupply</option>
                    <option value="3">BioPharma</option>
                </select>
            
            
            <button type="submit" class="btn btn-primary">Valider</button>

            <?php 
                // Affichage du message d'erreur
                if (!empty($_SESSION['message']['text'])) { 
            ?>
                <div class="alert <?= $_SESSION['message']['type'] ?>">
                    <?= $_SESSION['message']['text'] ?> 
                </div>
            <?php } ?>
             
        </form>            
    </div>
    
    <div class="box">
        <table class="mtable">
            <tr>
                <th>Nom du produit</th>
                <th>Description</th>
                <th>Quantités</th>
                <th>Date d'expiration</th>
            </tr>
            <!-- Exemple de ligne de tableau -->
             <?php 
             $medicament = getmedicament();

             if(!empty($medicament) && is_array($medicament)) {
                foreach($medicament as $medicaments) { 
                    ?>
                   <tr>
                    <td><?= $medicaments['nom'] ?></td>
                    <td><?= $medicaments['description'] ?></td>
                    <td><?= $medicaments['quantites'] ?></td>
                    <td><?= $medicaments['Date_expiration'] ?></td>
                   </tr>
                <?php 
                }
            } ?>    
        </table>
    </div>
</div>
</div>

    <?php include 'footer.php'; ?>
