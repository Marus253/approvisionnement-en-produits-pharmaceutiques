<?php include('connexion.php'); ?>

<?php 
// on crée une fonction qui va récupéré tout nos produits
function getmedicament() {
    $sql = "SELECT * FROM produits";
//on appelle notre fonctions sous formes globals vue qu'on est dans une fonction pour que ça marche
    $req = $GLOBALS['connexion']->prepare($sql);

    $req->execute();
//pour retourner le resultat de la requête
    return $req->fetchAll();
}
?>