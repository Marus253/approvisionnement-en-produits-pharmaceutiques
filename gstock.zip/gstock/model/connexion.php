<?php 
session_start();

$serveur = "localhost";
$utilisateur = "root";
$password = "";
$dbname="gstock";

try { 
    $connexion =new PDO ("mysql:host=$serveur;dbname=$dbname", $utilisateur, $password);
    $connexion->setAttribute(\PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion :".$e->getMessage());
}
?>