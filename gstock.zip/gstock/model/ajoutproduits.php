<?php 
include 'connexion.php';


if (
    !empty($_POST['nom']) 
    && !empty($_POST['description']) 
    && !empty($_POST['quantites']) 
    && !empty($_POST['date_expiration']) 
    && !empty($_POST['id_fournisseur'])
) {

    $sql = "INSERT INTO produits (nom, description, quantites, date_expiration, id_fournisseur) VALUES (?, ?, ?, ?, ?)";

    $req = $connexion->prepare($sql);

    $req->execute(array(
        $_POST['nom'],
        $_POST['description'],
        $_POST['quantites'],
        $_POST['date_expiration'],
        $_POST['id_fournisseur']
    ));

    if ($req->rowCount() != 0) {
        $_SESSION['message']['text'] = "Produit ajouté avec succès";
        $_SESSION['message']['type'] = "success";
    } else {
        $_SESSION['message']['text'] = "Une erreur s'est produite lors de l'ajout";
        $_SESSION['message']['type'] = "danger";
    }

} else {
    $_SESSION['message']['text'] = 'Une information obligatoire non renseignée';
}